import { motion, AnimatePresence } from 'motion/react';
import React, { useState, useEffect } from 'react';
import {
  Home,
  Sparkles,
  Briefcase,
  User,
  MessageSquare,
  Calendar,
  Phone,
  Clock,
  MapPin,
  ChevronRight,
  ShieldCheck,
  Award,
  Heart,
} from 'lucide-react';

import SplitText from './components/react-bits/SplitText';
import OptionWheel from './components/react-bits/OptionWheel';
import Dock from './components/react-bits/Dock';
import LightRays from './components/react-bits/LightRays';

import About from './components/About';
import Portfolio from './components/Portfolio';
import Reviews from './components/Reviews';
import BookingBot from './components/BookingBot';

const SERVICES = [
  {
    id: 's-1',
    name: 'Архитектура & Окрашивание',
    price: 40,
    duration: 45,
    description: 'Индивидуальный подбор формы с учетом геометрии вашего лица. Бережная коррекция гипоаллергенным воском Lycon или пинцетом, профессиональное окрашивание премиум-красителем Thuya с мягким пудровым следом на коже.',
  },
  {
    id: 's-2',
    name: 'Ламинирование & Уход Botox',
    price: 65,
    duration: 60,
    description: 'Долговременная фиксация и придание объема даже самым жестким волоскам. Насыщение структуры кератином и ботоксом для стимуляции роста, укрепления и глянцевого здорового блеска бровей.',
  },
  {
    id: 's-3',
    name: 'Коллагенирование бровей',
    price: 75,
    duration: 60,
    description: 'Инновационная итальянская SPA-процедура для глубокого восстановления волосков изнутри. Идеально разглаживает, увлажняет и уплотняет брови, обеспечивая безупречный вид без склеивания.',
  },
  {
    id: 's-4',
    name: 'Коррекция воском/пинцетом',
    price: 25,
    duration: 30,
    description: 'Деликатное удаление лишних и пушковых волосков воском премиум-класса с последующей доработкой формы пинцетом. Завершается нанесением охлаждающей маски против покраснений.',
  },
  {
    id: 's-5',
    name: 'Мужской Brow-Grooming',
    price: 30,
    duration: 30,
    description: 'Профессиональное прореживание и аккуратное оформление мужских бровей. Устранение нежелательных волосков с сохранением природной мужественности формы, симметрии и густоты.',
  },
];

export default function App() {
  const [selectedServiceIdx, setSelectedServiceIdx] = useState(0);
  const [activeSection, setActiveSection] = useState('home');

  // Monitor scroll positioning to update active section in the Dock
  useEffect(() => {
    const sections = ['home', 'services', 'portfolio', 'about', 'reviews', 'booking'];
    
    const handleScroll = () => {
      const scrollPosition = window.scrollY + window.innerHeight * 0.4;
      
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const dockItems = [
    { icon: <Home className="w-full h-full" />, label: 'Главная', href: '#home' },
    { icon: <Sparkles className="w-full h-full" />, label: 'Услуги', href: '#services' },
    { icon: <Briefcase className="w-full h-full" />, label: 'Портфолио', href: '#portfolio' },
    { icon: <User className="w-full h-full" />, label: 'О мастере', href: '#about' },
    { icon: <MessageSquare className="w-full h-full" />, label: 'Отзывы', href: '#reviews' },
    { icon: <Calendar className="w-full h-full" />, label: 'Запись', href: '#booking' },
  ];

  return (
    <div className="relative min-h-screen bg-neutral-950 text-white font-sans overflow-x-hidden selection:bg-amber-400 selection:text-black">
      
      {/* 1. HERO SECTION */}
      <section id="home" className="relative min-h-screen flex flex-col justify-between items-center px-6 py-12 md:px-12 text-center">
        {/* Ambient Light Rays Backdrop */}
        <LightRays intensity="high" className="opacity-90" />

        {/* Header Branding */}
        <div className="w-full max-w-6xl flex justify-between items-center z-10 border-b border-white/5 pb-6">
          <motion.div
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <span className="font-mono text-base tracking-widest font-semibold text-amber-400">
              _NATASHA.BROWS_
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            <span className="text-xs text-neutral-400 font-sans tracking-wide">
              BROW STUDIO
            </span>
          </motion.div>
          <div className="flex items-center gap-3">
            <a
              href="https://www.instagram.com/_natasha.brows_/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-full bg-neutral-900 hover:bg-neutral-800 text-xs font-semibold tracking-wider border border-neutral-800 hover:border-pink-500/30 text-neutral-300 hover:text-pink-400 transition-all cursor-pointer flex items-center gap-2"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.051.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
              </svg>
              INSTAGRAM
            </a>
            <motion.a
              href="#booking"
              initial={{ opacity: 0, x: 15 }}
              animate={{ opacity: 1, x: 0 }}
              className="px-5 py-2.5 rounded-full bg-amber-400 hover:bg-amber-300 text-xs font-semibold tracking-wider text-black transition-all cursor-pointer"
            >
              ОНЛАЙН ЗАПИСЬ
            </motion.a>
          </div>
        </div>

        {/* Hero Central Text content */}
        <div className="flex-1 flex flex-col justify-center items-center max-w-4xl z-10 my-16">
          {/* Animated luxury brow tag */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: 'spring', delay: 0.1 }}
            className="px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-mono uppercase tracking-widest mb-6"
          >
            Премиальный уход за вашими бровями
          </motion.div>

          {/* Large SplitText Title */}
          <h1 className="text-4xl sm:text-6xl md:text-8xl font-sans font-light tracking-tight leading-none mb-6">
            <SplitText
              text="Идеальные Брови"
              delay={0.2}
              direction="up"
              charClassName="text-white hover:text-amber-400 transition-colors duration-300"
            />
            <br />
            <span className="text-amber-400">Каждый День</span>
          </h1>

          {/* Subtitle description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-neutral-400 text-sm md:text-lg font-sans font-light max-w-2xl leading-relaxed mb-10"
          >
            Профессиональное оформление, долговременная укладка и глубокое коллагеновое восстановление в уютной домашней атмосфере от сертифицированного топ-мастера.
          </motion.p>

          {/* Main call-to-actions */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center w-full"
          >
            <a
              href="#services"
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-black font-semibold tracking-wide shadow-lg shadow-amber-400/10 hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer"
            >
              Смотреть услуги
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#booking"
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 hover:text-white border border-neutral-800 hover:border-neutral-700 font-semibold tracking-wide transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
            >
              Записаться в Telegram
            </a>
          </motion.div>
        </div>

        {/* Hero bottom details block */}
        <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 border-t border-white/5 text-left z-10">
          {[
            { icon: <ShieldCheck className="text-amber-400 w-5 h-5" />, title: 'Безопасность', text: '3-этапная стерилизация по СанПиН' },
            { icon: <Award className="text-amber-400 w-5 h-5" />, title: 'Качество', text: 'Премиум материалы: Lycon, Thuya, Elan' },
            { icon: <Heart className="text-amber-400 w-5 h-5" />, title: 'Забота', text: 'Уютная атмосфера, чай/кофе и уход' },
          ].map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 + idx * 0.1 }}
              className="flex items-start gap-3 p-4 bg-neutral-950/40 backdrop-blur-md rounded-2xl border border-neutral-900"
            >
              <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                {item.icon}
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">{item.title}</h4>
                <p className="text-xs text-neutral-400 mt-1 font-sans font-light">{item.text}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 2. SERVICES SECTION WITH OPTIONWHEEL */}
      <section id="services" className="relative py-24 px-6 md:px-12 bg-neutral-950 text-white overflow-hidden">
        {/* Soft backlight for services */}
        <div className="absolute inset-x-0 bottom-0 h-[400px] bg-gradient-to-t from-amber-500/3 via-transparent to-transparent pointer-events-none" />

        <div className="max-w-6xl mx-auto relative z-10">
          
          {/* Header section title */}
          <div className="text-center mb-16">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-amber-400 font-mono text-xs uppercase tracking-widest mb-3"
            >
              Интерактивный прайс-лист
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-5xl font-sans font-light tracking-tight"
            >
              Услуги и Стоимость
            </motion.h2>
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-xs text-neutral-500 mt-2 font-sans font-light"
            >
              Вращайте колесо или используйте стрелки для выбора услуги
            </motion.p>
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: '80px' }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="h-[1px] bg-amber-500/50 mx-auto mt-6"
            />
          </div>

          {/* Interactive Wheel Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center min-h-[350px]">
            
            {/* Interactive 3D OptionWheel container */}
            <div className="lg:col-span-5 flex justify-center">
              <OptionWheel
                options={SERVICES}
                selectedIndex={selectedServiceIdx}
                onChange={setSelectedServiceIdx}
                className="w-full"
              />
            </div>

            {/* Selected Service Detailed Card Display (Right) */}
            <div className="lg:col-span-7">
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedServiceIdx}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="bg-neutral-900/60 border border-neutral-800/80 rounded-3xl p-8 md:p-10 shadow-xl text-left relative overflow-hidden backdrop-blur-md"
                >
                  {/* Decorative faint glow */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 blur-[60px] rounded-full pointer-events-none" />

                  {/* Top tags */}
                  <div className="flex items-center justify-between border-b border-neutral-800/80 pb-6 mb-6">
                    <div className="flex items-center gap-3">
                      <span className="text-amber-400 font-mono text-2xl font-semibold">
                        {SERVICES[selectedServiceIdx].price} BYN
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-400 font-mono text-xs bg-neutral-950 px-3.5 py-1.5 rounded-full border border-neutral-800/60">
                      <Clock className="w-3.5 h-3.5 text-amber-500" />
                      <span>{SERVICES[selectedServiceIdx].duration} минут</span>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <div className="flex flex-col gap-4">
                    <h3 className="text-xl md:text-2xl font-sans font-medium text-white">
                      {SERVICES[selectedServiceIdx].name}
                    </h3>
                    <p className="text-neutral-300 text-sm md:text-base leading-relaxed font-sans font-light">
                      {SERVICES[selectedServiceIdx].description}
                    </p>
                  </div>

                  {/* Highlights section inside the card */}
                  <div className="mt-8 pt-6 border-t border-neutral-800/80 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                    <div className="text-xs text-neutral-400 font-sans font-light flex flex-col gap-1.5">
                      <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        <span>Только стерильные инструменты</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        <span>Консультация по уходу после визита</span>
                      </div>
                    </div>

                    <a
                      href="https://t.me/brow_master_booking_bot"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto py-3 px-6 rounded-xl bg-amber-400 hover:bg-amber-300 text-black text-xs font-semibold text-center transition-all shadow-md hover:shadow-lg shadow-amber-400/5 hover:-translate-y-0.5 cursor-pointer"
                    >
                      Забронировать услугу
                    </a>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

          </div>

        </div>
      </section>

      {/* 3. PORTFOLIO SECTION */}
      <Portfolio />

      {/* 4. ABOUT SECTION */}
      <About />

      {/* 5. REVIEWS SECTION */}
      <Reviews />

      {/* 6. TELEGRAM BOT BOOKING SECTION */}
      <BookingBot />

      {/* 7. CONTACTS & FOOTER */}
      <footer className="relative bg-neutral-950 text-white border-t border-neutral-900 pt-20 pb-32 px-6 md:px-12">
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 text-left mb-16">
            
            {/* Column 1: Brand Info */}
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-2">
                <span className="font-mono text-lg tracking-widest font-semibold text-amber-400">
                  _NATASHA.BROWS_
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
              </div>
              <p className="text-xs text-neutral-400 font-sans font-light leading-relaxed">
                Студия архитектуры, ламинирования и восстановления бровей Натальи. Подчеркиваю вашу естественную красоту с 2021 года.
              </p>
              
              {/* Social Links */}
              <div className="flex gap-3 mt-2">
                <a
                  href="https://t.me/brow_master_booking_bot"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-sky-400 hover:border-sky-500/30 transition-colors cursor-pointer"
                  aria-label="Telegram"
                >
                  <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15.45-.54 2.51-1.12 5.03-.25 1.07-.5 1.57-.75 1.6-.54.06-1.12-.3-1.64-.7-.66-.51-1.02-.82-1.65-1.24-.74-.49-.26-.76.16-1.2.11-.11 2.02-1.85 2.06-2.01.01-.03.01-.15-.06-.21-.07-.06-.18-.04-.26-.02-.11.02-1.89 1.2-5.34 3.53-.51.35-.97.52-1.37.51-.44-.01-1.29-.25-1.92-.45-.77-.25-1.38-.38-1.33-.8.03-.22.33-.45.92-.69 3.59-1.56 5.99-2.59 7.21-3.09 3.44-1.42 4.15-1.66 4.62-1.67.1 0 .33.02.48.15.12.1.16.24.18.35.01.07.02.26.01.42z" />
                  </svg>
                </a>
                <a
                  href="https://www.instagram.com/_natasha.brows_/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-pink-400 hover:border-pink-500/30 transition-colors cursor-pointer"
                  aria-label="Instagram"
                >
                  <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.051.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* Column 2: Working Hours */}
            <div className="flex flex-col gap-4">
              <h4 className="text-sm font-sans font-medium uppercase tracking-wider text-amber-400">
                Время работы
              </h4>
              <div className="flex flex-col gap-3 text-xs text-neutral-300 font-sans font-light">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-neutral-500" />
                  <span>Ежедневно: 10:00 — 21:00</span>
                </div>
                <p className="text-neutral-500">Прием осуществляется строго по предварительной онлайн-записи через Telegram-бота.</p>
              </div>
            </div>

            {/* Column 3: Address / Contacts */}
            <div className="flex flex-col gap-4">
              <h4 className="text-sm font-sans font-medium uppercase tracking-wider text-amber-400">
                Контакты
              </h4>
              <div className="flex flex-col gap-3 text-xs text-neutral-300 font-sans font-light">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-neutral-500" />
                  <span>Минск, пр. Независимости, 12</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-neutral-500" />
                  <span>+375 (29) 123-45-67</span>
                </div>
              </div>
            </div>

            {/* Column 4: Quick Actions */}
            <div className="flex flex-col gap-4">
              <h4 className="text-sm font-sans font-medium uppercase tracking-wider text-amber-400">
                Быстрые ссылки
              </h4>
              <div className="flex flex-col gap-2.5 text-xs text-neutral-300 font-sans font-light">
                <a href="#services" className="hover:text-amber-400 transition-colors">Стоимость услуг</a>
                <a href="#portfolio" className="hover:text-amber-400 transition-colors">Галерея работ</a>
                <a href="#about" className="hover:text-amber-400 transition-colors">О топ-мастере</a>
                <a href="#reviews" className="hover:text-amber-400 transition-colors">Отзывы гостей</a>
              </div>
            </div>

          </div>

          {/* Bottom Copyright Block */}
          <div className="border-t border-neutral-900 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-neutral-500">
            <p>© 2026 Lash & Brow Studio. Все права защищены.</p>
            <p className="flex items-center gap-1.5">
              Сайт разработан для
              <a href="https://www.instagram.com/_natasha.brows_/" target="_blank" rel="noopener noreferrer" className="text-amber-400 hover:underline">
                Натальи @_natasha.brows_
              </a>
            </p>
          </div>
        </div>
      </footer>

      {/* Floating macOS-Style Dock Navigation */}
      <Dock
        items={dockItems}
        activeSection={activeSection}
        onItemClick={(href) => {
          const el = document.getElementById(href.replace('#', ''));
          if (el) {
            el.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      />

    </div>
  );
}

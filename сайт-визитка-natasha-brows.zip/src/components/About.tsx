import { motion } from 'motion/react';
import React from 'react';

export default function About() {
  const stats = [
    { value: '5+', label: 'Лет опыта' },
    { value: '3 500+', label: 'Счастливых гостей' },
    { value: '15+', label: 'Сертификатов и дипломов' },
    { value: '100%', label: 'Безопасность и гигиена' },
  ];

  return (
    <section id="about" className="relative py-24 px-6 md:px-12 bg-neutral-900 text-white overflow-hidden">
      <div className="max-w-6xl mx-auto relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Master Profile Photo (Left) */}
          <div className="lg:col-span-5 relative">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative aspect-square md:aspect-[4/5] rounded-[32px] overflow-hidden border border-neutral-800 shadow-2xl group"
            >
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80"
                alt="Наталья — @natasha.brows"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

              {/* Float Card Info */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-black/60 backdrop-blur-md rounded-2xl border border-neutral-800">
                <h3 className="text-lg font-sans font-medium text-amber-400">Наталья</h3>
                <p className="text-xs text-neutral-400 mt-1">Основатель студии, топ-мастер @_natasha.brows_</p>
              </div>
            </motion.div>

            {/* Decorative Gold Elements */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-amber-500/20 rounded-tl-3xl pointer-events-none" />
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border-b-2 border-r-2 border-amber-500/20 rounded-br-3xl pointer-events-none" />
          </div>

          {/* Master Bio & Stats (Right) */}
          <div className="lg:col-span-7 text-left flex flex-col gap-6">
            <span className="text-amber-400 font-mono text-xs uppercase tracking-widest">
              О мастере
            </span>
            <h2 className="text-3xl md:text-5xl font-sans font-light tracking-tight leading-tight">
              Создаю брови с вашим характером
            </h2>
            <p className="text-neutral-300 text-sm md:text-base leading-relaxed font-sans font-light">
              Привет! Я Наталья, и в моем Instagram-блоге <a href="https://www.instagram.com/_natasha.brows_/" target="_blank" rel="noopener noreferrer" className="text-amber-400 hover:underline">@_natasha.brows_</a> я делюсь секретами идеального ухода за бровями. Я верю, что брови — это самый важный акцент лица, отражающий его характер и эмоции. Мой подход исключает шаблонные формы и угольно-черный цвет. Я создаю естественную, воздушную укладку и мягкие градиентные оттенки, которые гармонично дополняют вашу индивидуальность.
            </p>
            <p className="text-neutral-400 text-sm leading-relaxed font-sans font-light">
              Каждый инструмент проходит 3-ступенчатую медицинскую стерилизацию по стандартам СанПиН. В работе я использую исключительно сертифицированные премиум-составы из Австралии и Европы (Lycon, Thuya, Elan), чтобы процедуры были не только красивыми, но и безопасными для вашей кожи и волосков.
            </p>

            {/* Grid Stats block */}
            <div className="grid grid-cols-2 gap-6 mt-6 border-t border-neutral-800 pt-8">
              {stats.map((stat, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex flex-col gap-1.5"
                >
                  <span className="text-2xl md:text-3xl font-mono text-amber-400 font-medium">
                    {stat.value}
                  </span>
                  <span className="text-xs text-neutral-400 font-sans font-light">
                    {stat.label}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import React, { useState, useEffect } from 'react';

interface Message {
  id: number;
  sender: 'bot' | 'user';
  text: string;
  time: string;
  options?: string[];
}

const SIMULATOR_STEPS: Message[] = [
  {
    id: 1,
    sender: 'bot',
    text: 'Привет! Рада видеть тебя в сервисе онлайн-записи студии @_natasha.brows_. Какая процедура тебя интересует?',
    time: '12:00',
    options: ['Ламинирование бровей', 'Архитектура & Окрашивание', 'Коллагенирование'],
  },
  {
    id: 2,
    sender: 'user',
    text: 'Ламинирование бровей ✨',
    time: '12:00',
  },
  {
    id: 3,
    sender: 'bot',
    text: 'Прекрасный выбор! Ламинирование делает волоски мягкими и ухоженными. Выбери, пожалуйста, удобную дату:',
    time: '12:01',
    options: ['Пятница, 24 июля', 'Суббота, 25 июля', 'Воскресенье, 26 июля'],
  },
  {
    id: 4,
    sender: 'user',
    text: 'Суббота, 25 июля 📅',
    time: '12:01',
  },
  {
    id: 5,
    sender: 'bot',
    text: 'Доступные слоты на 25 июля. Выбери время:',
    time: '12:01',
    options: ['11:00', '14:00 (рекомендуется)', '17:30'],
  },
  {
    id: 6,
    sender: 'user',
    text: '14:00 🕐',
    time: '12:02',
  },
  {
    id: 7,
    sender: 'bot',
    text: '🎉 Отлично! Ты успешно записана на Ламинирование бровей 25 июля в 14:00. За час до процедуры бот напомнит тебе адрес студии. До встречи!',
    time: '12:02',
  },
];

export default function BookingBot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isTyping, setIsTyping] = useState(false);

  // Auto-play chat simulation in a loop
  useEffect(() => {
    if (currentStep === 0) {
      setMessages([SIMULATOR_STEPS[0]]);
      setCurrentStep(1);
      return;
    }

    if (currentStep >= SIMULATOR_STEPS.length) {
      const restartTimeout = setTimeout(() => {
        setMessages([]);
        setCurrentStep(0);
      }, 7000); // Wait 7s before restarting simulation
      return () => clearTimeout(restartTimeout);
    }

    const nextMsg = SIMULATOR_STEPS[currentStep];
    const isBot = nextMsg.sender === 'bot';

    const timeout = setTimeout(() => {
      if (isBot) {
        setIsTyping(true);
        const typingTimeout = setTimeout(() => {
          setIsTyping(false);
          setMessages((prev) => [...prev, nextMsg]);
          setCurrentStep((prev) => prev + 1);
        }, 1500); // Typing speed
        return () => clearTimeout(typingTimeout);
      } else {
        setMessages((prev) => [...prev, nextMsg]);
        setCurrentStep((prev) => prev + 1);
      }
    }, isBot ? 2200 : 1500); // Delay between bubbles

    return () => clearTimeout(timeout);
  }, [currentStep]);

  return (
    <section id="booking" className="relative py-24 px-6 md:px-12 bg-neutral-950 text-white overflow-hidden">
      <div className="max-w-6xl mx-auto relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Text content (Left) */}
          <div className="lg:col-span-5 text-left flex flex-col gap-6">
            <span className="text-amber-400 font-mono text-xs uppercase tracking-widest">
              Быстрая онлайн-запись
            </span>
            <h2 className="text-3xl md:text-5xl font-sans font-light tracking-tight leading-tight">
              Запись за 1 минуту в Telegram
            </h2>
            <p className="text-neutral-400 text-sm md:text-base leading-relaxed font-sans font-light">
              Забудьте о долгих переписках и звонках! В моем Telegram-боте вы можете мгновенно выбрать услугу, посмотреть свободные окошки, забронировать удобное время и управлять своими записями в один клик.
            </p>

            <ul className="flex flex-col gap-3 text-sm text-neutral-300 font-sans font-light">
              <li className="flex items-center gap-3">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-amber-400/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono text-xs">
                  ✓
                </span>
                Выбор любой услуги и мастера
              </li>
              <li className="flex items-center gap-3">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-amber-400/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono text-xs">
                  ✓
                </span>
                Автоматические напоминания о визите за 24 и 2 часа
              </li>
              <li className="flex items-center gap-3">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-amber-400/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono text-xs">
                  ✓
                </span>
                Возможность перенести или отменить запись кнопкой
              </li>
            </ul>

            <div className="mt-4">
              <a
                href="https://t.me/brow_master_booking_bot"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 py-4 px-8 rounded-2xl bg-sky-500 hover:bg-sky-400 text-white font-semibold shadow-lg shadow-sky-500/20 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl cursor-pointer"
              >
                {/* Official Telegram Icon SVG */}
                <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15.45-.54 2.51-1.12 5.03-.25 1.07-.5 1.57-.75 1.6-.54.06-1.12-.3-1.64-.7-.66-.51-1.02-.82-1.65-1.24-.74-.49-.26-.76.16-1.2.11-.11 2.02-1.85 2.06-2.01.01-.03.01-.15-.06-.21-.07-.06-.18-.04-.26-.02-.11.02-1.89 1.2-5.34 3.53-.51.35-.97.52-1.37.51-.44-.01-1.29-.25-1.92-.45-.77-.25-1.38-.38-1.33-.8.03-.22.33-.45.92-.69 3.59-1.56 5.99-2.59 7.21-3.09 3.44-1.42 4.15-1.66 4.62-1.67.1 0 .33.02.48.15.12.1.16.24.18.35.01.07.02.26.01.42z" />
                </svg>
                Запустиить Telegram Бота
              </a>
              <span className="block text-xs text-neutral-500 font-mono mt-3">
                *Бот откроется в приложении Telegram
              </span>
            </div>
          </div>

          {/* Interactive Chat Simulator (Right) */}
          <div className="lg:col-span-7 flex justify-center">
            <div className="relative w-full max-w-[360px] h-[580px] bg-neutral-900 border border-neutral-800 rounded-[44px] p-3 shadow-2xl shadow-black/80 flex flex-col overflow-hidden">
              {/* Phone Speaker & Camera Notch */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-6 bg-black rounded-b-2xl z-30 flex items-center justify-center">
                <div className="w-12 h-1 bg-neutral-800 rounded-full" />
              </div>

              {/* Telegram Screen Top Bar */}
              <div className="bg-neutral-950 pt-8 pb-3 px-6 rounded-t-[36px] flex items-center justify-between border-b border-neutral-900 z-20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-400 flex items-center justify-center font-sans font-semibold text-black text-sm">
                    NB
                  </div>
                  <div className="text-left">
                    <h4 className="text-xs font-semibold text-white">Natasha Brows Бот</h4>
                    <span className="text-[10px] text-emerald-400 font-medium">бот в сети</span>
                  </div>
                </div>
                <button className="text-neutral-500 hover:text-white">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                  </svg>
                </button>
              </div>

              {/* Message Feed Area */}
              <div className="flex-1 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-neutral-950 via-neutral-900 to-neutral-950 p-4 overflow-y-auto flex flex-col gap-4 scrollbar-thin scrollbar-thumb-neutral-800">
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ type: 'spring', damping: 20, stiffness: 300 }}
                    className={`flex flex-col max-w-[85%] ${
                      msg.sender === 'user' ? 'self-end items-end' : 'self-start items-start'
                    }`}
                  >
                    <div
                      className={`rounded-2xl px-3.5 py-2.5 text-xs text-left leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-sky-500 text-white rounded-tr-none'
                          : 'bg-neutral-800 text-neutral-100 rounded-tl-none border border-neutral-700/50'
                      }`}
                    >
                      {msg.text}
                    </div>
                    <span className="text-[9px] text-neutral-500 font-mono mt-1 px-1">
                      {msg.time}
                    </span>

                    {/* Bot buttons simulation */}
                    {msg.options && (
                      <div className="flex flex-col gap-1.5 mt-2.5 w-full">
                        {msg.options.map((opt, i) => (
                          <div
                            key={i}
                            className="bg-neutral-800/80 border border-neutral-700/80 hover:bg-neutral-700 hover:border-amber-500/30 text-center py-2 px-3 rounded-lg text-[11px] font-medium text-amber-400 cursor-default"
                          >
                            {opt}
                          </div>
                        ))}
                      </div>
                    )}
                  </motion.div>
                ))}

                {/* Animated Typing Indicator */}
                {isTyping && (
                  <div className="self-start flex items-center gap-1.5 bg-neutral-800 border border-neutral-700/50 rounded-2xl rounded-tl-none px-3.5 py-3.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                )}
              </div>

              {/* Bottom Message Input simulator bar */}
              <div className="bg-neutral-950 p-3 rounded-b-[36px] border-t border-neutral-900 flex items-center gap-3">
                <div className="flex-1 bg-neutral-900 rounded-full px-4 py-2 flex items-center text-left">
                  <span className="text-[10px] text-neutral-500">Написать сообщение...</span>
                </div>
                <div className="w-7 h-7 rounded-full bg-sky-500 flex items-center justify-center text-white">
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                  </svg>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}

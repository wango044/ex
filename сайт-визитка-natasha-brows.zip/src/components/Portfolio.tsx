import { motion, AnimatePresence } from 'motion/react';
import React, { useState } from 'react';
import { PortfolioItem } from '../types';

const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'port-1',
    title: 'Долговременная укладка & Botox',
    description: 'Идеальное ламинирование непослушных волосков с глубоким питанием ботоксом. Брови выглядят ухоженными, мягкими и пушистыми. Стойкость эффекта — до 6 недель.',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
    category: 'lamination',
  },
  {
    id: 'port-2',
    title: 'Графичное окрашивание & Архитектура',
    description: 'Создание четкой, гармоничной формы бровей с учетом анатомии лица. Окрашивание стойкой премиум-краской с деликатным следом на коже для эффекта легкого макияжа.',
    image: 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?auto=format&fit=crop&w=800&q=80',
    category: 'coloring',
  },
  {
    id: 'port-3',
    title: 'Коррекция воском & Деликатный пинцет',
    description: 'Чистое удаление нежелательных пушковых волосков премиальным гипоаллергенным воском Lycon, доработка формы пинцетом и нанесение успокаивающего геля с алоэ.',
    category: 'shaping',
    image: 'https://images.unsplash.com/photo-1626015569429-b684bc677567?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'port-4',
    title: 'Коллагеновое восстановление бровей',
    description: 'Элитная процедура глубокого восстановления волосков. Насыщает коллагеном, делает брови плотными, блестящими и послушными без эффекта склеивания.',
    image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=800&q=80',
    category: 'lamination',
  },
  {
    id: 'port-5',
    title: 'Натуральная хна с пудровым эффектом',
    description: 'Окрашивание органической хной в технике градиента. Придает мягкий естественный объем бровей, бережно ухаживает и стимулирует рост новых волосков.',
    image: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=800&q=80',
    category: 'coloring',
  },
  {
    id: 'port-6',
    title: 'Мужской brow-grooming',
    description: 'Естественная коррекция мужских бровей. Удаление лишних волосков на переносице и висках без придания излишней графичности. Сохранение мужественного вида.',
    image: 'https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?auto=format&fit=crop&w=800&q=80',
    category: 'shaping',
  },
];

export default function Portfolio() {
  const [filter, setFilter] = useState<'all' | 'lamination' | 'shaping' | 'coloring'>('all');
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  const filteredItems = PORTFOLIO_ITEMS.filter(
    (item) => filter === 'all' || item.category === filter
  );

  return (
    <section id="portfolio" className="relative py-24 px-6 md:px-12 bg-neutral-950 text-white overflow-hidden">
      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Title */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-amber-400 font-mono text-xs uppercase tracking-widest mb-3"
          >
            Галерея работ
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-light tracking-tight"
          >
            Примеры моих работ
          </motion.h2>
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: '80px' }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="h-[1px] bg-amber-500/50 mx-auto mt-6"
          />
        </div>

        {/* Filter Navigation */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {([
            { id: 'all', label: 'Все работы' },
            { id: 'lamination', label: 'Ламинирование' },
            { id: 'shaping', label: 'Коррекция' },
            { id: 'coloring', label: 'Окрашивание' },
          ] as const).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`relative px-5 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer ${
                filter === tab.id
                  ? 'text-black font-semibold'
                  : 'text-neutral-400 hover:text-white bg-neutral-900/40 border border-neutral-900'
              }`}
            >
              {filter === tab.id && (
                <motion.div
                  layoutId="activeFilterTab"
                  className="absolute inset-0 bg-amber-400 rounded-full z-0"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, ease: 'easeOut', delay: index * 0.05 }}
                onClick={() => setSelectedItem(item)}
                className="group relative h-96 rounded-2xl overflow-hidden bg-neutral-900 border border-neutral-900 cursor-pointer shadow-lg shadow-black/20 hover:border-amber-500/30 transition-all duration-300 hover:-translate-y-1"
              >
                {/* Image */}
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />

                {/* Bottom Overlay Gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-80" />

                {/* Floating Category Tag */}
                <span className="absolute top-4 right-4 bg-black/70 backdrop-blur-md text-amber-400 text-xs font-mono py-1 px-3 rounded-full border border-neutral-800">
                  {item.category === 'lamination' && 'Ламинирование'}
                  {item.category === 'shaping' && 'Коррекция'}
                  {item.category === 'coloring' && 'Окрашивание'}
                </span>

                {/* Title & Short Description */}
                <div className="absolute bottom-6 left-6 right-6 flex flex-col gap-2">
                  <h3 className="text-lg font-sans font-medium text-white group-hover:text-amber-300 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-neutral-300 line-clamp-2 font-sans font-light">
                    {item.description}
                  </p>
                  <span className="text-xs text-amber-400 font-mono mt-1 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    Подробнее
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Empty state */}
        {filteredItems.length === 0 && (
          <div className="text-center py-20 text-neutral-500">
            Нет работ в данной категории.
          </div>
        )}
      </div>

      {/* Lightbox / Modal */}
      <AnimatePresence>
        {selectedItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
            onClick={() => setSelectedItem(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative max-w-4xl w-full bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-neutral-400 hover:text-white border border-neutral-800 transition-colors cursor-pointer"
                aria-label="Close details"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

              {/* Modal Image */}
              <div className="w-full md:w-1/2 h-64 md:h-auto min-h-[300px] relative">
                <img
                  src={selectedItem.image}
                  alt={selectedItem.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Modal Description Content */}
              <div className="w-full md:w-1/2 p-8 md:p-10 flex flex-col justify-between bg-neutral-900/90 text-left overflow-y-auto">
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {selectedItem.category === 'lamination' && 'Ламинирование'}
                      {selectedItem.category === 'shaping' && 'Коррекция бровей'}
                      {selectedItem.category === 'coloring' && 'Окрашивание'}
                    </span>
                  </div>
                  <h3 className="text-2xl md:text-3xl font-sans font-light tracking-tight text-white">
                    {selectedItem.title}
                  </h3>
                  <p className="text-sm text-neutral-300 leading-relaxed font-sans font-light">
                    {selectedItem.description}
                  </p>
                </div>

                <div className="mt-8 flex flex-col gap-4 border-t border-neutral-800 pt-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-neutral-400">Рекомендуемая запись:</span>
                    <span className="text-amber-400 font-medium">Онлайн через TG-бот</span>
                  </div>
                  <a
                    href="https://t.me/brow_master_booking_bot"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3.5 px-6 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-center transition-all duration-200 shadow-lg shadow-amber-400/10 flex items-center justify-center gap-2 hover:-translate-y-0.5 cursor-pointer"
                  >
                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15.45-.54 2.51-1.12 5.03-.25 1.07-.5 1.57-.75 1.6-.54.06-1.12-.3-1.64-.7-.66-.51-1.02-.82-1.65-1.24-.74-.49-.26-.76.16-1.2.11-.11 2.02-1.85 2.06-2.01.01-.03.01-.15-.06-.21-.07-.06-.18-.04-.26-.02-.11.02-1.89 1.2-5.34 3.53-.51.35-.97.52-1.37.51-.44-.01-1.29-.25-1.92-.45-.77-.25-1.38-.38-1.33-.8.03-.22.33-.45.92-.69 3.59-1.56 5.99-2.59 7.21-3.09 3.44-1.42 4.15-1.66 4.62-1.67.1 0 .33.02.48.15.12.1.16.24.18.35.01.07.02.26.01.42z" />
                    </svg>
                    Записаться в боте
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
